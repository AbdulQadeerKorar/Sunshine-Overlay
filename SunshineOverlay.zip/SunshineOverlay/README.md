# Themed Dolphin (GameCube) – Super Mario Sunshine overlay pack
Official Dolphin source + stylized on-screen controls (glyphs instead of letters).
Glyphs: A = sun star, B = water drop, X = waves, Y = eye, Z = double chevron, Start = pointer,
L = crescent, R = spray, D-pad = four-petal compass. Pressed = warm gold glow.

1. New GitHub repo. Upload SunshineOverlay.zip (unzipped NOT needed) to the repo root.
2. Add file -> Create new file -> `.github/workflows/dolphin.yml` -> paste the workflow -> Commit.
3. Actions -> Build themed Dolphin. Takes roughly 40-90 min.
4. Download artifact `Dolphin-Sunshine-Themed`, install the APK.
5. In Dolphin: add your own disc dump (.iso/.rvz) via the + button.
All Dolphin features (widescreen hack, internal resolution, cheats, VSync, shader options) are the real ones.
