#!/usr/bin/env python3
"""
Regenerates Dolphin Android's on-screen-control PNGs in a stylized theme
(bone-silver linework on ink, warm sun-gold glow when pressed, glyphs instead of letters).
It reads each existing PNG's size and writes a themed image with the SAME filename and size,
so it works even if Dolphin renames or resizes its assets.

usage: python3 themegen.py <path to Source/Android/app/src/main/res>
"""
import sys, os, re, math, glob
import numpy as np
from PIL import Image, ImageDraw

BONE = (230, 234, 238); INK = (7, 9, 13); SLATE = (26, 31, 41); GOLD = (255, 215, 106)
SS = 4  # supersampling

GLYPH = {
    "gcpad_a": "star", "gcpad_b": "drop", "gcpad_x": "wave", "gcpad_y": "eye",
    "gcpad_z": "chevdown", "gcpad_start": "start", "gcpad_l": "moon", "gcpad_r": "spray",
    "gcpad_c": "dot", "wiimote_a": "star", "wiimote_b": "drop",
}
PREFIXES = ("gcpad_", "gcwii_", "wiimote_", "classic_", "nunchuk_")


def rgba(c, a): return (c[0], c[1], c[2], int(a))


def radial(size, cx, cy, r, inner, outer):
    w, h = size
    y, x = np.mgrid[0:h, 0:w]
    d = np.clip(np.hypot(x - cx, y - cy) / r, 0, 1)[..., None]
    a = np.array(inner, float); b = np.array(outer, float)
    return Image.fromarray((a + (b - a) * d).astype("uint8"), "RGBA")


def disk(img, cx, cy, r, inner, outer):
    layer = radial(img.size, cx, cy, r, inner, outer)
    mask = Image.new("L", img.size, 0)
    ImageDraw.Draw(mask).ellipse([cx - r, cy - r, cx + r, cy + r], fill=255)
    tmp = Image.new("RGBA", img.size, (0, 0, 0, 0)); tmp.paste(layer, (0, 0), mask)
    img.alpha_composite(tmp)


def ring(d, cx, cy, r, w, color):
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=color, width=max(1, int(w)))


def dline(d, p0, p1, w, color):
    d.line([p0, p1], fill=color, width=max(1, int(w)))
    for p in (p0, p1):
        d.ellipse([p[0] - w / 2, p[1] - w / 2, p[0] + w / 2, p[1] + w / 2], fill=color)


def polyline(d, pts, w, color):
    for a, b in zip(pts, pts[1:]): dline(d, a, b, w, color)


def diamond(d, x, y, s, color):
    d.polygon([(x, y - s), (x + s, y), (x, y + s), (x - s, y)], fill=color)


def bez(p0, p1, p2, p3, n=28):
    out = []
    for i in range(n + 1):
        t = i / n; u = 1 - t
        out.append((u**3*p0[0]+3*u*u*t*p1[0]+3*u*t*t*p2[0]+t**3*p3[0],
                    u**3*p0[1]+3*u*u*t*p1[1]+3*u*t*t*p2[1]+t**3*p3[1]))
    return out


def glyph(img, kind, cx, cy, s, color):
    d = ImageDraw.Draw(img, "RGBA")
    P = lambda x, y: (cx + x * s, cy + y * s)
    W = lambda u: u * s
    if kind == "star":      # Shine-Sprite style sun star
        pts = []
        for i in range(16):
            r = 0.52 if i % 2 == 0 else 0.22
            a = -math.pi / 2 + i * math.pi / 8
            pts.append(P(r * math.cos(a), r * math.sin(a)))
        d.polygon(pts, fill=color)
        ring(d, cx, cy, W(0.1), W(0.05), rgba(INK, 230))
    elif kind == "drop":    # FLUDD water drop
        path = (bez((0, -.52), (.12, -.25), (.4, 0), (.4, .22)) + bez((.4, .22), (.4, .38), (.22, .48), (0, .48))
                + bez((0, .48), (-.22, .48), (-.4, .38), (-.4, .22)) + bez((-.4, .22), (-.4, 0), (-.12, -.25), (0, -.52)))
        pts = [P(x, y) for x, y in path]
        polyline(d, pts + [pts[0]], W(.08), color)
        inner = [P(x * .45, y * .45 + .14) for x, y in path]
        d.polygon(inner, fill=color)
    elif kind == "wave":
        for oy in (-.17, .17):
            pts = [P(-.46 + i * .92 / 24, oy + .1 * math.sin(i / 24 * math.pi * 3)) for i in range(25)]
            polyline(d, pts, W(.09), color)
    elif kind == "eye":
        up = bez((-.5, 0), (-.2, -.42), (.2, -.42), (.5, 0)); lo = bez((.5, 0), (.2, .42), (-.2, .42), (-.5, 0))
        pts = [P(x, y) for x, y in up + lo]
        polyline(d, pts, W(.08), color)
        d.ellipse([cx - W(.15), cy - W(.15), cx + W(.15), cy + W(.15)], fill=color)
    elif kind == "chevdown":
        for oy in (-.2, .16):
            polyline(d, [P(-.38, oy), P(0, oy + .36), P(.38, oy)], W(.1), color)
    elif kind == "start":
        d.polygon([P(-.22, -.38), P(.38, 0), P(-.22, .38)], fill=color)
    elif kind == "moon":
        m = Image.new("L", img.size, 0); md = ImageDraw.Draw(m)
        md.ellipse([cx - W(.5), cy - W(.5), cx + W(.5), cy + W(.5)], fill=255)
        md.ellipse([cx + W(.22) - W(.44), cy - W(.08) - W(.44), cx + W(.22) + W(.44), cy - W(.08) + W(.44)], fill=0)
        col = Image.new("RGBA", img.size, color); tmp = Image.new("RGBA", img.size, (0, 0, 0, 0))
        tmp.paste(col, (0, 0), m); img.alpha_composite(tmp)
        diamond(d, cx + W(.3), cy + W(.28), W(.07), color)
    elif kind == "spray":
        o = P(-.36, 0)
        for ex, ey in ((.42, -.3), (.46, 0), (.42, .3)): dline(d, o, P(ex, ey), W(.08), color)
        d.ellipse([o[0] - W(.1), o[1] - W(.1), o[0] + W(.1), o[1] + W(.1)], fill=color)
    elif kind == "dot":
        ring(d, cx, cy, W(.32), W(.08), color)
        d.ellipse([cx - W(.1), cy - W(.1), cx + W(.1), cy + W(.1)], fill=color)
    else:                   # generic ornament
        diamond(d, cx, cy, W(.3), color)
        diamond(d, cx, cy, W(.12), rgba(INK, 230))


def round_button(w, h, kind, pressed):
    W, H = w * SS, h * SS
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(img, "RGBA")
    cx, cy = W / 2, H / 2; R = min(W, H) / 2; r = R * 0.9
    acc = GOLD if pressed else BONE
    if pressed: img.alpha_composite(radial((W, H), cx, cy, R, rgba(acc, 110), rgba(acc, 0)))
    if pressed: disk(img, cx, cy, r, rgba(acc, 90), rgba(acc, 30))
    else: disk(img, cx, cy, r, rgba(INK, 205), rgba(SLATE, 215))
    d = ImageDraw.Draw(img, "RGBA")
    ring(d, cx, cy, r, r * 0.05, rgba(acc, 240))
    ring(d, cx, cy, r * 0.82, max(1, r * 0.022), rgba(acc, 110))
    for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)): diamond(d, cx + dx * r, cy + dy * r, r * .075, rgba(acc, 240))
    glyph(img, kind, cx, cy, r * .72, rgba(acc, 245))
    return img.resize((w, h), Image.LANCZOS)


def pill(w, h, kind, pressed):
    W, H = w * SS, h * SS
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(img, "RGBA")
    acc = GOLD if pressed else BONE; m = H * .05; rad = (H - 2 * m) / 2
    box = [m, m, W - m, H - m]
    d.rounded_rectangle(box, rad, fill=rgba(acc, 85) if pressed else rgba(INK, 205), outline=rgba(acc, 240), width=max(1, int(H * .035)))
    q = H * .14
    d.rounded_rectangle([m + q, m + q, W - m - q, H - m - q], max(1, rad - q), outline=rgba(acc, 100), width=max(1, int(H * .016)))
    diamond(d, m + rad * .55, H / 2, rad * .2, rgba(acc, 230)); diamond(d, W - m - rad * .55, H / 2, rad * .2, rgba(acc, 230))
    glyph(img, kind, W / 2, H / 2, H * .3, rgba(acc, 245))
    return img.resize((w, h), Image.LANCZOS)


def compass(w, h, lit):
    W, H = w * SS, h * SS
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    cx, cy = W / 2, H / 2; r = min(W, H) / 2 * 0.9
    img.alpha_composite(radial((W, H), cx, cy, r * 1.12, rgba(BONE, 30), rgba(BONE, 0)))
    d = ImageDraw.Draw(img, "RGBA")
    ring(d, cx, cy, r * 1.04, max(1, r * .012), rgba(BONE, 70))
    for a in (-135, -45, 45, 135):
        t = math.radians(a); diamond(d, cx + r * .72 * math.cos(t), cy + r * .72 * math.sin(t), r * .06, rgba(BONE, 150))
    ww = .24
    base = [(0, -1), (ww, -.52), (ww * .62, -.25), (-ww * .62, -.25), (-ww, -.52)]
    for key, deg in (("U", 0), ("R", 90), ("D", 180), ("L", 270)):
        t = math.radians(deg); on = key in lit
        pts = [(cx + r * (x * math.cos(t) - y * math.sin(t)), cy + r * (x * math.sin(t) + y * math.cos(t))) for x, y in base]
        d.polygon(pts, fill=rgba(GOLD, 170) if on else rgba(SLATE, 215))
        d.line(pts + [pts[0]], fill=rgba(GOLD if on else BONE, 240), width=max(1, int(r * .028)), joint="curve")
        a0 = (cx + r * (0 * math.cos(t) - (-.86) * math.sin(t)), cy + r * (0 * math.sin(t) + (-.86) * math.cos(t)))
        a1 = (cx + r * (0 * math.cos(t) - (-.4) * math.sin(t)), cy + r * (0 * math.sin(t) + (-.4) * math.cos(t)))
        d.line([a0, a1], fill=rgba(INK if on else BONE, 200 if on else 110), width=max(1, int(r * .014)))
    disk(img, cx, cy, r * .2, rgba(INK, 245), rgba(INK, 245))
    d = ImageDraw.Draw(img, "RGBA")
    ring(d, cx, cy, r * .2, r * .026, rgba(BONE, 240)); ring(d, cx, cy, r * .13, max(1, r * .012), rgba(BONE, 110))
    diamond(d, cx, cy, r * .065, rgba(BONE, 240))
    return img.resize((w, h), Image.LANCZOS)


def stick_range(w, h):
    W, H = w * SS, h * SS
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(img, "RGBA")
    cx, cy = W / 2, H / 2; r = min(W, H) / 2 * .94
    disk(img, cx, cy, r, rgba(INK, 70), rgba(SLATE, 110)); d = ImageDraw.Draw(img, "RGBA")
    ring(d, cx, cy, r, r * .02, rgba(BONE, 210)); ring(d, cx, cy, r * .9, max(1, r * .01), rgba(BONE, 90))
    for i in range(8):
        t = math.radians(i * 45)
        d.line([(cx + r * .9 * math.cos(t), cy + r * .9 * math.sin(t)), (cx + r * math.cos(t), cy + r * math.sin(t))],
               fill=rgba(BONE, 200), width=max(1, int(r * .02)))
    for i in range(4): diamond(d, cx + r * math.cos(math.radians(i * 90)), cy + r * math.sin(math.radians(i * 90)), r * .045, rgba(BONE, 240))
    return img.resize((w, h), Image.LANCZOS)


def make(name, w, h):
    base = name; pressed = "_pressed" in base
    key = re.sub(r"_pressed.*$", "", base)
    if "dpad" in base:
        lit = set()
        if "one_direction" in base: lit = {"U"}
        elif "two_direction" in base: lit = {"U", "R"}
        elif pressed: lit = {"U"}
        return compass(w, h, lit)
    if "joystick_range" in base or base.endswith("_range"): return stick_range(w, h)
    if "joystick" in base: return round_button(w, h, "orb", pressed)
    kind = GLYPH.get(key, "diamond")
    if w / float(h) > 1.6 or h / float(w) > 1.6: return pill(w, h, kind, pressed) if w >= h else pill(h, w, kind, pressed).rotate(90, expand=True)
    return round_button(w, h, kind, pressed)


def main(res):
    done, skipped = 0, []
    for dd in sorted(glob.glob(os.path.join(res, "drawable*"))):
        for f in sorted(glob.glob(os.path.join(dd, "*.png"))):
            name = os.path.splitext(os.path.basename(f))[0]
            if not name.startswith(PREFIXES): continue
            try:
                w, h = Image.open(f).size
                make(name, w, h).save(f, optimize=True); done += 1
                print("themed", os.path.relpath(f, res), (w, h))
            except Exception as e:
                skipped.append((f, str(e)))
    for f, e in skipped: print("SKIPPED", f, e)
    print("done:", done, "themed,", len(skipped), "skipped")
    if done == 0: print("WARNING: no overlay PNGs found - check Dolphin's res folder layout")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else ".")
